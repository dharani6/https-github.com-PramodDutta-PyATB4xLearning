# Program to find the Max number between two intergers.
# 34, 100 -> 100
print(max(34, 100,101))
print(max(10, 23, 45, -1, -2, 100, 1, 87.34))

