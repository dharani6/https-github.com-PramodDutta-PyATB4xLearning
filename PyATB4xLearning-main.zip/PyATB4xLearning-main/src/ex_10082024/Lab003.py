# Python Program
print("Hello World!")

# Builtsin.py all the important already built by Python guys
# these are like utilities.

# print() -
# self - Concept in OOps which points to itself - ignore.
# *args - Unlimited number of arguments * - string, int, float, boolean..
# file=None - File IO


# sep=' ' - How you want to separate the arguments
# end='\n' - in the end what you want to do

print("Hello", "World", "Amit", "Pramod", 123, 3.14, True, sep="|", end="  ")
print("Pramod")
