age = 65
# age - variable - identifer
# 123 = 34 -> Not possible - A-Z, a-z

# They start with a letter (A-Z or a-z)
# an underscore (_) followed by zero or more letters,
# underscores, and digits (0-9).
# Python is case-sensitive,
# so myVariable and myvariable are two different identifiers.

a = 10
_ = 45
_ = _+1
print(_)

abc123 = 78
#123abc = 90
_pramod = "amit"
_abc = 23
#$123 = 67
#&123 = 23


pi = 3.14
name = "Pramod"
isMale = True
print(type(name))
print(type(isMale))
print(type(pi))

complex_number = 2 + 3j
print(complex_number.real)
print(complex_number.imag)