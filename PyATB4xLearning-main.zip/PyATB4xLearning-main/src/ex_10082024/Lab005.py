# 1+1=2 #SyntaxError
# Source Code - Human readble code,code written by the humans - HLL
# Source Code -> We have to follow some rules - Python rules

print("Good", "Pramod", sep="?", end="_")
print("Amit")
