long_var_name_is_created_here = "Hello"
print(long_var_name_is_created_here)