a = 10
b = 10
c = 10
sum = a + b + c
sum = sum - 11
sum = sum + 1
sum=sum+1
print(sum)
