a, b, c = 45, 54, 67
print(a, b, c, sep="_")
