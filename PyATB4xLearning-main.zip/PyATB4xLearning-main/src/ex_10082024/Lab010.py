# Dynamically typed
# At the run time, data of the variable can be changed. and you don't need to
# mention the data type - Python - Int is very smart

age = 45
print(type(age))
age = "Pramod"
print(age)
print(type(age))