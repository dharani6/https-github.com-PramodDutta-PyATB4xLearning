# This is Comment - which doesn't run.
print("Hello Pramod, Welcome to the Learnin Python.")
print(2+2)
print(2-2)